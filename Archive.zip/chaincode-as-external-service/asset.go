package main

// SimpleAsset ...
type SimpleAsset struct {
	Content 	string `json:"content"`
	TxID    	string `json:"txID"`
	Provider    string `json:"provider"`
}
